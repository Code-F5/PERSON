/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Dell
 */
public class PersonHistory {
    
    private ArrayList<PersonDetails> persondetails;
    
    public PersonHistory(){
    this.persondetails = new ArrayList<PersonDetails>();
    }

    public ArrayList<PersonDetails> getPersondetails() {
        return persondetails;
    }

    public void setPersondetails(ArrayList<PersonDetails> persondetails) {
        this.persondetails = persondetails;
    }

    public void deletePerson(PersonDetails selectedperson) {
        persondetails.remove(selectedperson);
    }

    public PersonDetails addNewPerson() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
